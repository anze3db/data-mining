import cPickle
import crossValidation

NUM_TREES = 500
LIMIT = 80
FILTER = 0.441

#randomForestCross1600-50-results.pickle
all = cPickle.load(file("../randomForest-"+str(NUM_TREES)+"-results.pickle"))

fscore = []
results = []
for i in all['training'][1600:]:
    tt = [int(a[1:]) for a in  i.keys() if i[a]['real'] == 'T']
    if(len(tt) == 0): continue
    s = sorted(i.items(), key=lambda t: t[1]['predicted'], reverse=True)
    
    # NORMALIZED:
    #for i,x in enumerate(s):
    #    s[i][1]['predicted'] = s[i][1]['predicted']/s[0][1]['predicted']
    #pt = [int(x[0][1:]) for i,x in enumerate(s) if x[1]['predicted'] > 0.1+(i*LIMIT)]
    
    # DYNAMIC THRESH:
    pt = [int(x[0][1:]) for i,x in enumerate(s) if x[1]['predicted'] > s[0][1]['predicted']*(FILTER)]
    
    #print tt, pt, crossValidation.f_score(tt, pt)
    fscore.append(crossValidation.f_score(tt, pt)) 
for i in all['test']:
    s = sorted(i.items(), key=lambda t: t[1]['predicted'], reverse=True)
    
    # NORMALIZED:
    
    #for i,x in enumerate(s):
    #    s[i][1]['predicted'] = s[i][1]['predicted']/s[0][1]['predicted']
    #pt = [int(x[0][1:]) for i,x in enumerate(s) if x[1]['predicted'] > 0.1+(i*LIMIT)]
    
    # DYNAMIC THRESH:
    pt = [int(x[0][1:]) for i,x in enumerate(s) if x[1]['predicted'] > s[0][1]['predicted']*(FILTER)]
    #print pt
    results.append(pt)
finalScore = sum(fscore)/(float(len(fscore)))
print finalScore


if True:
    f = open('../resultRF-%.5f.csv' % finalScore , 'w')
    for r in results:
        result = r
        aa = ""
        for i in result:
            aa += str(i) + " "
        
        f.write(aa[:-1] + "\n")
    f.close()
    #crossValidation.f_score(tt, pt)